package com.example.postest4_rahmiatulmawaddah_2009106076

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
