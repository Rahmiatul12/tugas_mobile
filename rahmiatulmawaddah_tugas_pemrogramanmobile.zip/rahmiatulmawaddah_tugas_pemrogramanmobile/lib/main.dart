import 'package:flutter/material.dart';
import 'package:rahmiatulmawaddah_tugas_pemrogramanmobile/halaman1.dart';

import 'halaman2.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/Second',
      routes: {
        '/Second': (context) => const MyHomePage(),
      },
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

Widget boxed4() {
  return Container(
    alignment: Alignment.center,
    child: Container(
      margin: EdgeInsets.only(
        top: 20,
      ),
      width: 400,
      height: 370,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.topCenter,
          child: Text('Hi, Welcome To ',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 30,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
        Container(
          alignment: Alignment.topCenter,
          margin: EdgeInsets.only(top: 50),
          child: Text('Electronic Goods',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 20,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
      ]),
    ),
  );
}

Widget boxed5(BuildContext context) {
  return Container(
    alignment: Alignment.center,
    child: Container(
      margin: EdgeInsets.only(
        top: 60,
      ),
      width: 400,
      height: 370,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.topCenter,
          child: ElevatedButton(
            onPressed: () {
              final snackBar = SnackBar(
                content: Container(
                  child: Text("Anda Telah Masuk Ke Menu Awal"),
                ),
                duration: Duration(seconds: 4),
                padding: EdgeInsets.all(10),
                backgroundColor: Color.fromARGB(255, 0, 24, 95),
              );
              ScaffoldMessenger.of(context).showSnackBar(snackBar);
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return halaman1();
              }));
            },
            child: Text(
              "Home",
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 20,
                color: Color.fromARGB(255, 255, 255, 255),
              ),
            ),
            style: ElevatedButton.styleFrom(
              primary: Color.fromARGB(255, 0, 24, 95),
            ),
          ),
        ),
        Container(
          alignment: Alignment.topCenter,
          margin: EdgeInsets.only(top: 50),
          child: Text('press to login',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 15,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
      ]),
    ),
  );
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        alignment: Alignment.topLeft,
        width: lebar,
        height: tinggi,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('produk/b2.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: ListView(children: <Widget>[
          boxed4(),
          boxed5(context),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [],
            ),
          ),
        ]),
      ),
    );
  }
}
