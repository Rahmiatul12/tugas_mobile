import 'package:flutter/material.dart';

import 'halaman2.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: handpone(),
    );
  }
}

Widget myContainer1() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: DecorationImage(
        image: AssetImage('produk/hp1.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 108, 105, 105),
          offset: Offset(1, 1),
          blurRadius: 1,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' HandPhone \n Rp.1.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer2() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromRGBO(228, 174, 197, 1),
      image: DecorationImage(
        image: AssetImage('produk/hp2.jpg'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 97, 96, 96),
          offset: Offset(1, 1),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' HandPhone \n Rp.4.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer3() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 9, 9, 9),
      image: DecorationImage(
        image: AssetImage('produk/hp3.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' HandPhone  \n Rp.2.000.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer4() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromRGBO(228, 174, 197, 1),
      image: DecorationImage(
        image: AssetImage('produk/hp4.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' Handphone \n Rp.2.150.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer5() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 0, 0, 0),
      image: DecorationImage(
        image: AssetImage('produk/hp5.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 252, 251, 251),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('HandPhone \n Rp.3.150.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer6() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 255, 255, 255),
      image: DecorationImage(
        image: AssetImage('produk/hp6.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(1, 1),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('Handphone \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 0, 0, 0),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Color.fromARGB(255, 0, 0, 0),
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer7() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 0, 145, 255),
      image: DecorationImage(
        image: AssetImage('produk/hp7.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(1, 1),
          blurRadius: 5,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' HandPhone \n Rp.1.500.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer8() {
  return Container(
    width: 200,
    height: 300,
    margin: const EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 0, 0, 0),
      image: const DecorationImage(
        image: AssetImage('produk/8.png'),
      ),
      boxShadow: const [
        BoxShadow(
          color: Color.fromARGB(255, 255, 255, 255),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),

    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('HandPhone\n Rp.2.500.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget Bawah2() {
  return Container(
    margin: EdgeInsets.only(top: 15),
    child: Text(' Popular ',
        textAlign: TextAlign.left,
        style: TextStyle(
          fontFamily: 'Bookman',
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Color.fromARGB(235, 0, 0, 0),
        )),
  );
}

Widget Judul() {
  return Container(
    alignment: Alignment.topCenter,
    margin: EdgeInsets.only(top: 10),
    child: Text(
      "HandPhone",
      style: TextStyle(
        fontSize: 50,
        fontWeight: FontWeight.bold,
        fontFamily: 'cursive',
        color: Color.fromARGB(235, 240, 148, 148),
        shadows: [
          Shadow(
            color: Color.fromARGB(255, 0, 0, 0),
            offset: Offset(1, 1),
            blurRadius: 5,
          ),
        ],
      ),
    ),
  );
}

Widget Box(BuildContext context) {
  return Container(
    alignment: Alignment.bottomRight,
    child: Container(
      margin: EdgeInsets.only(right: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Color.fromARGB(235, 249, 246, 246),
        boxShadow: [
          BoxShadow(
            color: Color.fromARGB(255, 0, 0, 0),
            offset: Offset(1, 1),
            blurRadius: 5,
          ),
        ],
      ),
      child: IconButton(
        icon: Icon(
          Icons.undo,
          size: 30,
          color: Color.fromARGB(255, 0, 0, 0),
        ),
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) {
            return electronic();
          }));
        },
      ),
    ),
  );
}

class handpone extends StatelessWidget {
  const handpone({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return electronic();
              }));
            },
            color: Color.fromARGB(255, 236, 154, 154),
          ),
          title: const Text('Rahmiatul'),
          titleTextStyle: TextStyle(
            fontFamily: 'cursive',
            fontSize: 28,
            color: Color.fromARGB(247, 4, 4, 4),
          ),
          backgroundColor: Color.fromARGB(247, 254, 251, 251),
        ),
        body: Container(
          alignment: Alignment.topLeft,
          width: lebar,
          height: tinggi,
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [
              Color.fromARGB(255, 255, 255, 255),
              Color.fromARGB(235, 255, 255, 255),
            ]),
          ),
          child: ListView(
            children: <Widget>[
              Judul(),
              Box(context),
              Container(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    child: Row(
                      children: [
                        myContainer1(),
                        myContainer2(),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    child: Row(
                      children: [
                        myContainer3(),
                        myContainer4(),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    child: Row(
                      children: [
                        myContainer5(),
                        myContainer6(),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    child: Row(
                      children: [
                        myContainer7(),
                        myContainer8(),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
