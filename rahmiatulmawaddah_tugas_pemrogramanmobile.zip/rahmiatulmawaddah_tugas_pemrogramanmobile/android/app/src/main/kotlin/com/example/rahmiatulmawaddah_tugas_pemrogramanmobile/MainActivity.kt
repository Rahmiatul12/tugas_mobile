package com.example.rahmiatulmawaddah_tugas_pemrogramanmobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
